export const environment = {
    production: true,
    api_url: 'https://marketing.natuzzi.com/server/api',
    version: require('../../package.json').version
};
