import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remind-user-name',
  templateUrl: './remind-user-name.component.html',
  styleUrls: ['./remind-user-name.component.scss']
})
export class RemindUserNameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
