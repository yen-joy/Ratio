import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-features',
  templateUrl: './user-features.component.html',
  styleUrls: ['./user-features.component.scss']
})
export class UserFeaturesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
