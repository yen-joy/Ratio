import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-features',
  templateUrl: './admin-features.component.html',
  styleUrls: ['./admin-features.component.scss']
})
export class AdminFeaturesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
