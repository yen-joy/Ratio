export class Page {
    size: number = 0;
    totalElements: number = 0;
    totalPages: number = 0;
    offset: number = 0;
}